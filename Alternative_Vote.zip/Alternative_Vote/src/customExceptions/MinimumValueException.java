public class MinimumValueException extends Exception {
    private int value = 0;
    
    public MinimumValueException(int num) {
        this.value = num;
    }

    public String getMessage(){
        return "[Error]: Value must be greater than " + value;
    }
}
    

